# Video Respaldo 4.0

Copia los vídeos de la memoria interna a la microSD (carpeta `VideoRespaldo`, con las mismas carpetas),
verifica cada copia con SHA-256 y, solo si tú lo confirmas, borra los originales verificados.
Muestra porcentaje, tiempo transcurrido, tiempo restante y velocidad.

Compila con GitHub Actions: pestaña **Actions** → **Compilar APK v4** → **Artifacts** → `VideoRespaldo-v4-APK`.

package com.example.videorespaldo

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.storage.StorageManager
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.Locale

/**
 * VIDEO RESPALDO 4.0 - motor de respaldo.
 *
 * Flujo:
 *   1) Buscar vídeos en la memoria interna.
 *   2) Copiarlos a la microSD (carpeta VideoRespaldo) conservando la misma estructura de carpetas.
 *   3) Verificar cada copia leyéndola de nuevo y comparando su SHA-256 con el del original.
 *   4) Solo si el usuario lo confirma: borrar los originales verificados (las carpetas no se tocan).
 *
 * Todo el trabajo pesado corre en un hilo aparte; la pantalla solo recibe "fotos" (Snapshot) del avance.
 */

enum class Phase { IDLE, SCANNING, COPYING, VERIFYING, READY_TO_DELETE, DELETING, DONE, ERROR }

class SdVolume(val label: String, val root: File)

class VideoItem(
    val file: File,
    val relDir: String,
    val size: Long,
    val modified: Long
) {
    var target: File? = null
    var hash: String? = null
    var verified: Boolean = false
    var failed: Boolean = false
    var deleted: Boolean = false
}

class Snapshot(
    val phase: Phase,
    val title: String,
    val current: String,
    val percent: Int,
    val filesDone: Int,
    val filesTotal: Int,
    val failed: Int,
    val totalBytes: Long,
    val speedBps: Long,
    val elapsedMs: Long,
    val etaMs: Long,
    val readyCount: Int,
    val readyBytes: Long,
    val running: Boolean,
    val log: List<String>
)

object Fmt {
    fun size(bytes: Long): String {
        val b = bytes.toDouble()
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        return when {
            b >= gb -> String.format(Locale.getDefault(), "%.2f GB", b / gb)
            b >= mb -> String.format(Locale.getDefault(), "%.1f MB", b / mb)
            b >= kb -> String.format(Locale.getDefault(), "%.0f KB", b / kb)
            else -> "$bytes B"
        }
    }

    fun time(ms: Long): String {
        if (ms < 0L) return "--:--"
        val total = ms / 1000L
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val s = total % 60L
        return if (h > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.US, "%02d:%02d", m, s)
        }
    }
}

private class CancelledException : RuntimeException("Cancelado")

object BackupEngine {

    const val BACKUP_FOLDER = "VideoRespaldo"

    private const val BUFFER = 1024 * 1024
    private const val MIN_AGE_MS = 20000L
    private const val SPACE_MARGIN = 256L * 1024L * 1024L

    private val EXTENSIONS = setOf(
        "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "mpeg", "mpg",
        "m4v", "3gp", "3g2", "ts", "mts", "m2ts", "vob", "ogv", "asf", "divx"
    )

    private var appContext: Context? = null
    private val main = Handler(Looper.getMainLooper())

    @Volatile var listener: ((Snapshot) -> Unit)? = null

    @Volatile private var phase: Phase = Phase.IDLE
    @Volatile private var title: String = "Listo para respaldar"
    @Volatile private var current: String = ""
    @Volatile private var workTotal: Long = 0L
    @Volatile private var workDone: Long = 0L
    @Volatile private var filesTotal: Int = 0
    @Volatile private var filesDone: Int = 0
    @Volatile private var failedCount: Int = 0
    @Volatile private var totalBytes: Long = 0L
    @Volatile private var startedAt: Long = 0L
    @Volatile private var finishedElapsed: Long = 0L
    @Volatile private var speed: Double = 0.0
    @Volatile private var running: Boolean = false
    @Volatile private var cancelRequested: Boolean = false
    @Volatile private var items: List<VideoItem> = emptyList()

    private val logLines = ArrayList<String>()
    @Volatile private var lastPublish: Long = 0L
    private var lastSampleT: Long = 0L
    private var lastSampleW: Long = 0L

    // =====================================================================
    //  API pública
    // =====================================================================

    fun attach(ctx: Context) {
        appContext = ctx.applicationContext
    }

    fun isRunning(): Boolean = running

    fun findVolumes(ctx: Context): List<SdVolume> {
        val out = ArrayList<SdVolume>()
        try {
            val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            for (v in sm.storageVolumes) {
                if (v.isPrimary || !v.isRemovable) continue
                if (v.state != Environment.MEDIA_MOUNTED) continue
                val dir = v.directory ?: continue
                val label: String = v.getDescription(ctx) ?: "Tarjeta de memoria"
                out.add(SdVolume(label, dir))
            }
        } catch (e: Exception) {
            // sin volúmenes
        }
        return out
    }

    fun start(sdRoot: File) {
        if (running) return
        val ctx = appContext ?: return
        running = true
        cancelRequested = false
        val t = Thread { runBackup(ctx, sdRoot) }
        t.name = "respaldo-trabajo"
        t.start()
    }

    fun startDelete() {
        if (running) return
        val ctx = appContext ?: return
        val list = ArrayList<VideoItem>()
        for (v in items) {
            if (v.verified && !v.failed && !v.deleted) list.add(v)
        }
        if (list.isEmpty()) return
        running = true
        cancelRequested = false
        val t = Thread { runDelete(ctx, list) }
        t.name = "respaldo-borrado"
        t.start()
    }

    fun cancel() {
        if (running) {
            cancelRequested = true
            log("Cancelando…")
            publish(true)
        }
    }

    fun snapshot(): Snapshot {
        val list = items
        var readyCount = 0
        var readyBytes = 0L
        for (v in list) {
            if (v.verified && !v.failed && !v.deleted) {
                readyCount++
                readyBytes += v.size
            }
        }
        val ph = phase
        val total = workTotal
        var pct = if (total > 0L) ((workDone * 100L) / total).toInt() else 0
        if (pct > 99) pct = 99
        if (ph == Phase.IDLE || ph == Phase.SCANNING) pct = 0
        if (ph == Phase.READY_TO_DELETE || ph == Phase.DONE) pct = 100

        val isRun = running
        val elapsed = if (isRun) SystemClock.elapsedRealtime() - startedAt else finishedElapsed
        val working = ph == Phase.COPYING || ph == Phase.VERIFYING
        var eta = -1L
        if (isRun && working && speed > 1.0 && total > workDone) {
            eta = (((total - workDone).toDouble() / speed) * 1000.0).toLong()
        }
        val spd = if (isRun && working) speed.toLong() else 0L

        val logCopy: List<String> = synchronized(logLines) {
            ArrayList<String>(logLines.takeLast(30))
        }

        return Snapshot(
            phase = ph,
            title = title,
            current = current,
            percent = pct,
            filesDone = filesDone,
            filesTotal = filesTotal,
            failed = failedCount,
            totalBytes = totalBytes,
            speedBps = spd,
            elapsedMs = elapsed,
            etaMs = eta,
            readyCount = readyCount,
            readyBytes = readyBytes,
            running = isRun,
            log = logCopy
        )
    }

    // =====================================================================
    //  Respaldo: buscar -> copiar -> verificar
    // =====================================================================

    private fun runBackup(ctx: Context, sdRoot: File) {
        val wake = acquireWake(ctx)
        try {
            beginJob()
            setPhase(Phase.SCANNING, "Buscando vídeos…")

            val backupRoot = File(sdRoot, BACKUP_FOLDER)
            prepareDestination(backupRoot)

            val internal = Environment.getExternalStorageDirectory()
            val found = scan(internal)
            if (found.isEmpty()) {
                log("No se encontraron vídeos.")
                setPhase(Phase.DONE, "No se encontraron vídeos en la memoria interna")
                return
            }

            var total = 0L
            var toWrite = 0L
            for (v in found) {
                total += v.size
                val dir = if (v.relDir.isEmpty()) backupRoot else File(backupRoot, v.relDir)
                val same = File(dir, v.file.name)
                if (!(same.isFile && same.length() == v.size)) toWrite += v.size
            }
            val free = sdRoot.usableSpace
            if (free < toWrite + SPACE_MARGIN) {
                throw IOException(
                    "No hay espacio suficiente en la microSD. Se necesitan " +
                        Fmt.size(toWrite + SPACE_MARGIN) + " y hay " + Fmt.size(free) + " libres."
                )
            }

            items = found
            totalBytes = total
            workTotal = total * 2L
            workDone = 0L
            filesTotal = found.size
            log("Vídeos encontrados: ${found.size} (${Fmt.size(total)})")

            // ---- Fase 1: copiar ----
            setPhase(Phase.COPYING, "Copiando vídeos a la microSD")
            filesDone = 0
            for (v in found) {
                checkCancel()
                copyItem(backupRoot, v)
                filesDone++
            }

            // ---- Fase 2: verificar ----
            setPhase(Phase.VERIFYING, "Verificando que cada copia sea idéntica")
            filesDone = 0
            for (v in found) {
                checkCancel()
                verifyItem(v)
                filesDone++
            }

            var ok = 0
            for (v in found) {
                if (v.verified && !v.failed) ok++
            }
            log("Verificados: $ok de ${found.size}. Con problemas: $failedCount.")
            if (ok > 0) {
                val t = if (failedCount == 0) {
                    "Respaldo verificado"
                } else {
                    "Respaldo listo; $failedCount vídeos quedaron sin verificar"
                }
                setPhase(Phase.READY_TO_DELETE, t)
            } else {
                setPhase(Phase.DONE, "Ninguna copia pudo verificarse; no se puede borrar nada")
            }
        } catch (e: CancelledException) {
            items = emptyList()
            log("Operación cancelada.")
            phase = Phase.IDLE
            title = "Cancelado"
            current = ""
        } catch (e: Throwable) {
            val msg = e.message ?: e.javaClass.simpleName
            log("Error: $msg")
            phase = Phase.ERROR
            title = msg
            current = ""
        } finally {
            releaseWake(wake)
            finishedElapsed = SystemClock.elapsedRealtime() - startedAt
            running = false
            publish(true)
        }
    }

    private fun beginJob() {
        items = emptyList()
        failedCount = 0
        filesDone = 0
        filesTotal = 0
        totalBytes = 0L
        workTotal = 0L
        workDone = 0L
        speed = 0.0
        finishedElapsed = 0L
        startedAt = SystemClock.elapsedRealtime()
        lastSampleT = startedAt
        lastSampleW = 0L
        log("— Nuevo respaldo —")
    }

    private fun prepareDestination(root: File) {
        if (!root.exists() && !root.mkdirs() && !root.exists()) {
            throw IOException(
                "No se pudo crear la carpeta $BACKUP_FOLDER en la microSD. " +
                    "Revisa que el acceso a todos los archivos esté concedido."
            )
        }
        val probe = File(root, ".prueba_escritura")
        try {
            FileOutputStream(probe).use { o ->
                o.write(1)
                o.fd.sync()
            }
        } catch (e: Exception) {
            throw IOException("La microSD no permite escribir directamente: ${e.message}")
        } finally {
            probe.delete()
        }
    }

    private fun scan(internal: File): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val seen = HashSet<String>()
        val stack = java.util.ArrayDeque<File>()
        stack.push(internal)
        val androidData = File(internal, "Android/data").path
        val androidObb = File(internal, "Android/obb").path
        val now = System.currentTimeMillis()
        val basePath = internal.path

        while (!stack.isEmpty()) {
            checkCancel()
            val dir = stack.pop()
            val canon: String = try {
                dir.canonicalPath
            } catch (e: IOException) {
                continue
            }
            if (!seen.add(canon)) continue
            val children = dir.listFiles()
            if (children == null) {
                log("No se pudo leer: ${dir.path}")
                continue
            }
            for (f in children) {
                val name = f.name
                if (f.isDirectory) {
                    if (f.path == androidData || f.path == androidObb) continue
                    if (name == ".thumbnails" || name == ".Trash" || name == ".trash") continue
                    stack.push(f)
                } else if (f.isFile) {
                    if (name.startsWith(".trashed-") || name.startsWith(".pending-")) continue
                    val dot = name.lastIndexOf('.')
                    if (dot <= 0 || dot == name.length - 1) continue
                    val ext = name.substring(dot + 1).lowercase(Locale.ROOT)
                    if (!EXTENSIONS.contains(ext)) continue
                    val size = f.length()
                    val modified = f.lastModified()
                    if (size <= 0L) continue
                    if (now - modified < MIN_AGE_MS) {
                        log("Se omitió (se está escribiendo): $name")
                        continue
                    }
                    val parentPath = f.parent ?: basePath
                    val rel = if (parentPath.length > basePath.length) parentPath.substring(basePath.length + 1) else ""
                    out.add(VideoItem(f, rel, size, modified))
                }
            }
            current = dir.name
            title = "Buscando vídeos… ${out.size} encontrados"
            publish()
        }
        out.sortWith(compareBy<VideoItem>({ it.relDir }, { it.file.name }))
        return out
    }

    private fun label(v: VideoItem): String {
        return if (v.relDir.isEmpty()) v.file.name else v.relDir + "/" + v.file.name
    }

    private fun suffixed(name: String, n: Int): String {
        if (n == 0) return name
        val dot = name.lastIndexOf('.')
        return if (dot > 0) {
            name.substring(0, dot) + "_" + n + name.substring(dot)
        } else {
            name + "_" + n
        }
    }

    private fun copyItem(root: File, v: VideoItem) {
        current = label(v)
        try {
            val dir = if (v.relDir.isEmpty()) root else File(root, v.relDir)
            if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
                throw IOException("No se pudo crear la carpeta ${dir.path}")
            }
            var n = 0
            var srcHash: String? = null
            while (true) {
                checkCancel()
                if (n > 200) throw IOException("Demasiados archivos con el mismo nombre en el destino")
                val cand = File(dir, suffixed(v.file.name, n))
                if (!cand.exists()) {
                    val h = copyFile(v, cand)
                    v.target = cand
                    v.hash = h
                    break
                }
                if (cand.isFile && cand.length() == v.size) {
                    // Ya hay una copia con el mismo tamaño: se comparan los SHA-256 antes de reutilizarla.
                    if (srcHash == null) srcHash = hashFile(v.file)
                    val destHash = hashFile(cand)
                    if (destHash == srcHash) {
                        if (v.file.length() != v.size || v.file.lastModified() != v.modified) {
                            throw IOException("El original cambió; se omitió")
                        }
                        v.target = cand
                        v.hash = srcHash
                        v.verified = true
                        break
                    }
                }
                n++
            }
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            v.failed = true
            failedCount++
            log("✗ ${v.file.name}: ${e.message}")
        }
    }

    private fun copyFile(v: VideoItem, target: File): String {
        val tmp = File(target.parentFile, target.name + ".part")
        val md = MessageDigest.getInstance("SHA-256")
        try {
            FileInputStream(v.file).use { input ->
                FileOutputStream(tmp).use { output ->
                    val buf = ByteArray(BUFFER)
                    while (true) {
                        checkCancel()
                        val n = input.read(buf)
                        if (n < 0) break
                        md.update(buf, 0, n)
                        output.write(buf, 0, n)
                        addWork(n.toLong())
                    }
                    output.flush()
                    output.fd.sync()
                }
            }
            if (tmp.length() != v.size) throw IOException("La copia quedó incompleta")
            if (v.file.length() != v.size || v.file.lastModified() != v.modified) {
                throw IOException("El original cambió mientras se copiaba; se omitió")
            }
            if (!tmp.renameTo(target)) throw IOException("No se pudo finalizar la copia")
            target.setLastModified(v.modified)
            return hex(md.digest())
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun verifyItem(v: VideoItem) {
        if (v.failed || v.verified) return
        val t = v.target
        val expected = v.hash
        if (t == null || expected == null) {
            v.failed = true
            failedCount++
            return
        }
        current = label(v)
        try {
            if (!t.isFile || t.length() != v.size) throw IOException("la copia no tiene el tamaño correcto")
            val h = hashFile(t)
            if (h != expected) {
                t.delete()
                throw IOException("la copia no coincide con el original (se eliminó la copia dañada)")
            }
            v.verified = true
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            v.failed = true
            failedCount++
            log("✗ ${v.file.name}: ${e.message}")
        }
    }

    private fun hashFile(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(BUFFER)
        FileInputStream(f).use { input ->
            while (true) {
                checkCancel()
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                addWork(n.toLong())
            }
        }
        return hex(md.digest())
    }

    // =====================================================================
    //  Borrado de originales verificados
    // =====================================================================

    private fun runDelete(ctx: Context, list: List<VideoItem>) {
        val wake = acquireWake(ctx)
        try {
            startedAt = SystemClock.elapsedRealtime()
            finishedElapsed = 0L
            speed = 0.0
            var bytes = 0L
            for (v in list) bytes += v.size
            workTotal = bytes
            workDone = 0L
            filesTotal = list.size
            filesDone = 0
            lastSampleT = startedAt
            lastSampleW = 0L
            setPhase(Phase.DELETING, "Borrando originales verificados")
            log("— Borrado de originales —")

            val deletedPaths = ArrayList<String>()
            var freed = 0L
            var skipped = 0
            for (v in list) {
                checkCancel()
                current = label(v)
                val t = v.target
                val src = v.file
                if (t == null || !t.isFile || t.length() != v.size) {
                    v.failed = true
                    skipped++
                    log("Se conservó ${v.file.name}: la copia ya no está completa")
                } else if (!src.exists()) {
                    v.deleted = true
                } else if (src.length() != v.size || src.lastModified() != v.modified) {
                    v.failed = true
                    skipped++
                    log("Se conservó ${v.file.name}: el original cambió después de la copia")
                } else if (src.delete()) {
                    v.deleted = true
                    freed += v.size
                    deletedPaths.add(src.path)
                } else {
                    v.failed = true
                    skipped++
                    log("No se pudo borrar ${v.file.name}")
                }
                filesDone++
                addWork(v.size)
            }

            if (deletedPaths.isNotEmpty()) {
                try {
                    MediaScannerConnection.scanFile(ctx, deletedPaths.toTypedArray(), null, null)
                } catch (e: Exception) {
                    // la galería se actualizará sola más tarde
                }
            }
            log("Borrados: ${deletedPaths.size}. Conservados: $skipped. Liberado: ${Fmt.size(freed)}.")
            setPhase(Phase.DONE, "Listo: se liberaron " + Fmt.size(freed))
        } catch (e: CancelledException) {
            log("Borrado cancelado.")
            phase = Phase.READY_TO_DELETE
            title = "Borrado cancelado"
            current = ""
        } catch (e: Throwable) {
            val msg = e.message ?: e.javaClass.simpleName
            log("Error: $msg")
            phase = Phase.ERROR
            title = msg
            current = ""
        } finally {
            releaseWake(wake)
            finishedElapsed = SystemClock.elapsedRealtime() - startedAt
            running = false
            publish(true)
        }
    }

    // =====================================================================
    //  Utilidades
    // =====================================================================

    private fun setPhase(p: Phase, t: String) {
        phase = p
        title = t
        current = ""
        publish(true)
    }

    private fun checkCancel() {
        if (cancelRequested) throw CancelledException()
    }

    private fun addWork(n: Long) {
        workDone += n
        val now = SystemClock.elapsedRealtime()
        if (now - lastSampleT >= 1000L) {
            val dt = (now - lastSampleT) / 1000.0
            val inst = (workDone - lastSampleW) / dt
            speed = if (speed <= 0.0) inst else speed * 0.7 + inst * 0.3
            lastSampleT = now
            lastSampleW = workDone
        }
        publish()
    }

    private fun publish(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPublish < 200L) return
        lastPublish = now
        main.post {
            val l = listener
            if (l != null) l(snapshot())
        }
    }

    private fun log(msg: String) {
        synchronized(logLines) {
            logLines.add(msg)
            while (logLines.size > 300) logLines.removeAt(0)
        }
    }

    private fun hex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) sb.append(String.format("%02x", x.toInt() and 0xff))
        return sb.toString()
    }

    private fun acquireWake(ctx: Context): PowerManager.WakeLock? {
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VideoRespaldo:trabajo")
            wl.acquire(12L * 60L * 60L * 1000L)
            wl
        } catch (e: Exception) {
            null
        }
    }

    private fun releaseWake(wl: PowerManager.WakeLock?) {
        try {
            if (wl != null && wl.isHeld) wl.release()
        } catch (e: Exception) {
            // nada
        }
    }
}

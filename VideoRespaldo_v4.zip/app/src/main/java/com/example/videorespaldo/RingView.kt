package com.example.videorespaldo

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View

/** Anillo de progreso con degradado y el porcentaje en el centro. */
class RingView(context: Context) : View(context) {

    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val big = Paint(Paint.ANTI_ALIAS_FLAG)
    private val small = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val density: Float = resources.displayMetrics.density

    private var shown = 0f
    private var target = -1f
    private var anim: ValueAnimator? = null

    var caption: String = "en espera"
        set(value) {
            field = value
            invalidate()
        }

    init {
        val stroke = 14f * density
        track.style = Paint.Style.STROKE
        track.strokeWidth = stroke
        track.color = Color.parseColor("#1B2645")

        arc.style = Paint.Style.STROKE
        arc.strokeWidth = stroke
        arc.strokeCap = Paint.Cap.ROUND

        big.color = Color.parseColor("#EAF0FF")
        big.textAlign = Paint.Align.CENTER
        big.textSize = 52f * density
        big.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

        small.color = Color.parseColor("#8E9BBE")
        small.textAlign = Paint.Align.CENTER
        small.textSize = 14f * density
    }

    fun setPercent(p: Int) {
        val t = p.coerceIn(0, 100).toFloat()
        if (t == target) return
        target = t
        anim?.cancel()
        val a = ValueAnimator.ofFloat(shown, t)
        a.duration = 400L
        a.addUpdateListener { va ->
            shown = va.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val pad = arc.strokeWidth
        rect.set(pad, pad, w - pad, h - pad)
        arc.shader = SweepGradient(
            w / 2f,
            h / 2f,
            intArrayOf(Color.parseColor("#22D3EE"), Color.parseColor("#8B5CF6")),
            null
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawArc(rect, 0f, 360f, false, track)
        if (shown > 0.2f) {
            canvas.save()
            canvas.rotate(-90f, width / 2f, height / 2f)
            canvas.drawArc(rect, 0f, 360f * shown / 100f, false, arc)
            canvas.restore()
        }
        val cx = width / 2f
        val cy = height / 2f
        val baseline = cy + big.textSize * 0.20f
        canvas.drawText(shown.toInt().toString() + "%", cx, baseline, big)
        canvas.drawText(caption, cx, baseline + big.textSize * 0.48f, small)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

package com.example.videorespaldo

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * VIDEO RESPALDO 4.0 - pantalla principal.
 * Solo dibuja: el trabajo real lo hace BackupEngine en otro hilo.
 */
class MainActivity : Activity() {

    private val colBg = Color.parseColor("#0A0F1F")
    private val colCard = Color.parseColor("#121A30")
    private val colStroke = Color.parseColor("#1F2B4A")
    private val colText = Color.parseColor("#EAF0FF")
    private val colMuted = Color.parseColor("#8E9BBE")
    private val colAccent = Color.parseColor("#22D3EE")
    private val colWarn = Color.parseColor("#FBBF24")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var permCard: LinearLayout
    private lateinit var tvDest: TextView
    private lateinit var tvDestHint: TextView
    private lateinit var ring: RingView
    private lateinit var tvPhase: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var stElapsed: TextView
    private lateinit var stRemaining: TextView
    private lateinit var stSpeed: TextView
    private lateinit var stVideos: TextView
    private lateinit var stSize: TextView
    private lateinit var stFailed: TextView
    private lateinit var btnStart: Button
    private lateinit var btnCancel: Button
    private lateinit var btnDelete: Button
    private lateinit var tvLog: TextView

    private var volumes: List<SdVolume> = emptyList()
    private var volIndex = 0
    private var lastSnap: Snapshot? = null

    // =====================================================================
    //  Ciclo de vida
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BackupEngine.attach(this)
        window.statusBarColor = colBg
        window.navigationBarColor = colBg
        setContentView(buildUi())
    }

    override fun onStart() {
        super.onStart()
        BackupEngine.listener = { s -> render(s) }
        render(BackupEngine.snapshot())
    }

    override fun onResume() {
        super.onResume()
        refreshVolumes(false)
        render(BackupEngine.snapshot())
    }

    override fun onStop() {
        BackupEngine.listener = null
        super.onStop()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (BackupEngine.isRunning()) {
            Toast.makeText(
                this,
                "Hay un proceso en curso. Deja la app abierta o usa CANCELAR.",
                Toast.LENGTH_LONG
            ).show()
        } else {
            super.onBackPressed()
        }
    }

    // =====================================================================
    //  Construcción de la interfaz
    // =====================================================================

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(colBg)
        scroll.isFillViewport = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(30), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        col.addView(label("Video Respaldo", 30f, colText, true))
        col.addView(label("Copia, verifica y libera tu memoria interna.", 14f, colMuted, false))

        // ---- Permiso ----
        permCard = card()
        permCard.addView(label("Falta un permiso", 16f, colWarn, true))
        permCard.addView(
            label(
                "Android pide \"Acceso a todos los archivos\" para poder leer tus vídeos y " +
                    "copiarlos a la microSD. Solo se usa para este respaldo.",
                13f, colMuted, false
            )
        )
        val btnPerm = button("Conceder acceso", "#FBBF24", "#F59E0B", "#1A1203", false)
        btnPerm.setOnClickListener { requestPermission() }
        permCard.addView(btnPerm)
        col.addView(permCard)

        // ---- Destino ----
        val destCard = card()
        destCard.addView(label("DESTINO", 11f, colMuted, true))
        tvDest = label("Buscando microSD…", 18f, colText, true)
        destCard.addView(tvDest)
        tvDestHint = label("", 12f, colMuted, false)
        destCard.addView(tvDestHint)
        destCard.setOnClickListener { refreshVolumes(true) }
        col.addView(destCard)

        // ---- Progreso ----
        val pc = card()
        ring = RingView(this)
        val rlp = LinearLayout.LayoutParams(dp(220), dp(220))
        rlp.gravity = Gravity.CENTER_HORIZONTAL
        rlp.topMargin = dp(6)
        pc.addView(ring, rlp)

        tvPhase = label("Listo para respaldar", 17f, colText, true)
        tvPhase.gravity = Gravity.CENTER_HORIZONTAL
        tvPhase.setPadding(0, dp(10), 0, 0)
        pc.addView(tvPhase)

        tvCurrent = label(" ", 12f, colMuted, false)
        tvCurrent.gravity = Gravity.CENTER_HORIZONTAL
        tvCurrent.setSingleLine(true)
        tvCurrent.ellipsize = TextUtils.TruncateAt.MIDDLE
        pc.addView(tvCurrent)

        val row1 = statRow()
        stElapsed = addStat(row1, "Transcurrido")
        stRemaining = addStat(row1, "Restante")
        stSpeed = addStat(row1, "Velocidad")
        pc.addView(row1)

        val row2 = statRow()
        stVideos = addStat(row2, "Vídeos")
        stSize = addStat(row2, "Tamaño total")
        stFailed = addStat(row2, "Con problemas")
        pc.addView(row2)
        col.addView(pc)

        // ---- Botones ----
        btnStart = button("Iniciar respaldo y verificación", "#22D3EE", "#3B82F6", "#04111F", false)
        btnStart.setOnClickListener { onStartClicked() }
        col.addView(btnStart)

        btnCancel = button("Cancelar", "#00000000", "#00000000", "#EAF0FF", true)
        btnCancel.setOnClickListener { BackupEngine.cancel() }
        btnCancel.visibility = View.GONE
        col.addView(btnCancel)

        btnDelete = button("Borrar originales verificados", "#F87171", "#EF4444", "#FFFFFF", false)
        btnDelete.setOnClickListener { confirmDelete() }
        btnDelete.visibility = View.GONE
        col.addView(btnDelete)

        val note = label(
            "Nada se borra hasta que tú lo confirmes, y solo después de comparar el SHA-256 " +
                "de cada copia con su original. Las carpetas nunca se borran.",
            12f, colMuted, false
        )
        note.setPadding(dp(4), dp(12), dp(4), 0)
        col.addView(note)

        // ---- Registro ----
        val logCard = card()
        logCard.addView(label("REGISTRO", 11f, colMuted, true))
        tvLog = label("Sin eventos todavía.", 11f, colMuted, false)
        tvLog.typeface = Typeface.MONOSPACE
        logCard.addView(tvLog)
        col.addView(logCard)

        return scroll
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setPadding(0, dp(2), 0, dp(2))
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(16), dp(18), dp(16))
        val bg = GradientDrawable()
        bg.setColor(colCard)
        bg.cornerRadius = dp(20).toFloat()
        bg.setStroke(dp(1), colStroke)
        c.background = bg
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(14)
        c.layoutParams = lp
        return c
    }

    private fun button(text: String, c1: String, c2: String, textColor: String, outline: Boolean): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.parseColor(textColor))
        b.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        b.stateListAnimator = null
        val shape = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor(c1), Color.parseColor(c2))
        )
        shape.cornerRadius = dp(28).toFloat()
        if (outline) shape.setStroke(dp(1), colMuted)
        b.background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), shape, null)
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(14)
        b.layoutParams = lp
        return b
    }

    private fun statRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(14)
        r.layoutParams = lp
        return r
    }

    private fun addStat(row: LinearLayout, caption: String): TextView {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        val cap = label(caption, 11f, colMuted, false)
        cap.gravity = Gravity.CENTER_HORIZONTAL
        val value = label("—", 16f, colText, true)
        value.gravity = Gravity.CENTER_HORIZONTAL
        cell.addView(cap)
        cell.addView(value)
        row.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
        return value
    }

    private fun setOn(b: Button, on: Boolean) {
        b.isEnabled = on
        b.alpha = if (on) 1f else 0.4f
    }

    // =====================================================================
    //  Acciones
    // =====================================================================

    private fun hasPermission(): Boolean = Environment.isExternalStorageManager()

    private fun requestPermission() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                Toast.makeText(this, "No se pudo abrir los ajustes de permisos.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshVolumes(cycle: Boolean) {
        if (BackupEngine.isRunning()) return
        volumes = BackupEngine.findVolumes(this)
        if (cycle && volumes.size > 1) volIndex = (volIndex + 1) % volumes.size
        if (volIndex >= volumes.size) volIndex = 0
        if (volumes.isEmpty()) {
            tvDest.text = "No se detectó una microSD"
            tvDestHint.text = "Inserta la tarjeta y toca aquí para buscarla de nuevo."
        } else {
            val v = volumes[volIndex]
            tvDest.text = v.label
            var hint = "Libre: " + Fmt.size(v.root.usableSpace) +
                " · Se copia en " + BackupEngine.BACKUP_FOLDER + "/ con las mismas carpetas"
            if (volumes.size > 1) hint += " · Toca para cambiar de tarjeta"
            tvDestHint.text = hint
        }
    }

    private fun onStartClicked() {
        if (!hasPermission()) {
            requestPermission()
            return
        }
        if (volumes.isEmpty()) {
            Toast.makeText(this, "No se detectó ninguna microSD.", Toast.LENGTH_LONG).show()
            return
        }
        BackupEngine.start(volumes[volIndex].root)
    }

    private fun confirmDelete() {
        val s = lastSnap ?: return
        if (s.readyCount <= 0) return
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Borrar originales")
            .setMessage(
                "Se borrarán " + s.readyCount + " vídeos (" + Fmt.size(s.readyBytes) +
                    ") de la memoria interna.\n\nSus copias en la microSD ya fueron verificadas " +
                    "una por una. Las carpetas no se tocan.\n\nEsta acción no se puede deshacer."
            )
            .setPositiveButton("Borrar") { _, _ -> BackupEngine.startDelete() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // =====================================================================
    //  Pintar el estado
    // =====================================================================

    private fun render(s: Snapshot) {
        lastSnap = s
        val perm = hasPermission()
        permCard.visibility = if (perm) View.GONE else View.VISIBLE

        if (s.running) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        ring.setPercent(s.percent)
        ring.caption = when (s.phase) {
            Phase.READY_TO_DELETE -> "respaldado"
            Phase.DONE -> "listo"
            Phase.ERROR -> "error"
            Phase.IDLE -> "en espera"
            Phase.SCANNING -> "buscando"
            else -> "completado"
        }
        tvPhase.text = s.title
        tvCurrent.text = if (s.current.isEmpty()) " " else s.current

        stElapsed.text = Fmt.time(s.elapsedMs)
        stRemaining.text = if (s.running && s.etaMs >= 0L) Fmt.time(s.etaMs) else "--:--"
        stSpeed.text = if (s.speedBps > 0L) Fmt.size(s.speedBps) + "/s" else "—"
        stVideos.text = if (s.filesTotal > 0) s.filesDone.toString() + "/" + s.filesTotal else "—"
        stSize.text = if (s.totalBytes > 0L) Fmt.size(s.totalBytes) else "—"
        stFailed.text = s.failed.toString()

        setOn(btnStart, !s.running && perm && volumes.isNotEmpty())
        btnCancel.visibility = if (s.running) View.VISIBLE else View.GONE

        val showDelete = !s.running && s.readyCount > 0
        btnDelete.visibility = if (showDelete) View.VISIBLE else View.GONE
        if (showDelete) {
            btnDelete.text = "Borrar originales verificados\n" + s.readyCount + " vídeos · " + Fmt.size(s.readyBytes)
        }

        if (s.log.isEmpty()) {
            tvLog.text = "Sin eventos todavía."
        } else {
            val sb = StringBuilder()
            var i = s.log.size - 1
            while (i >= 0) {
                sb.append(s.log[i]).append('\n')
                i--
            }
            tvLog.text = sb.toString().trimEnd()
        }
    }
}

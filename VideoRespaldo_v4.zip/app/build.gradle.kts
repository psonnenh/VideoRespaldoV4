plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.videorespaldo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.videorespaldo"
        minSdk = 30
        targetSdk = 34
        versionCode = 40
        versionName = "4.0"
    }

    // Firma fija: las futuras versiones se instalan encima de esta sin desinstalar.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
